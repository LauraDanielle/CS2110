/*
 * Exported with nin10kit v1.1
 * Time-stamp: Monday 11/09/2015, 20:04:24
 * 
 * Image Information
 * -----------------
 * /home/laura/Documents/HW10/door.jpg 8@16
 * /home/laura/Documents/HW10/key.png 8@8
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 0) 32@32
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 1) 32@32
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 2) 32@32
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 3) 32@32
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 4) 32@32
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 5) 32@32
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 6) 32@32
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 7) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 0) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 1) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 2) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 3) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 4) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 5) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 6) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 7) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 8) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 9) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 10) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 11) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 12) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 13) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 14) 32@32
 * /home/laura/Documents/HW10/link.gif (frame 15) 32@32
 * /home/laura/Documents/HW10/GameOver.png 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef GAMEOVER_H
#define GAMEOVER_H

#define SPRITES_PALETTE_TYPE (1 << 13)
#define SPRITES_DIMENSION_TYPE (1 << 6)

extern const unsigned short sprites_palette[256];
#define SPRITES_PALETTE_SIZE 256

extern const unsigned short sprites[12384];
#define SPRITES_SIZE 12384

#define DOOR_SPRITE_SHAPE (2 << 14)
#define DOOR_SPRITE_SIZE (0 << 14)
#define DOOR_ID 0

#define KEY_SPRITE_SHAPE (0 << 14)
#define KEY_SPRITE_SIZE (0 << 14)
#define KEY_ID 4

#define STALFOS_ENEMY0_ID 6

#define STALFOS_ENEMY1_ID 38

#define STALFOS_ENEMY2_ID 70

#define STALFOS_ENEMY3_ID 102

#define STALFOS_ENEMY4_ID 134

#define STALFOS_ENEMY5_ID 166

#define STALFOS_ENEMY6_ID 198

#define STALFOS_ENEMY7_ID 230

#define LINK0_ID 262

#define LINK1_ID 294

#define LINK2_ID 326

#define LINK3_ID 358

#define LINK4_ID 390

#define LINK5_ID 422

#define LINK6_ID 454

#define LINK7_ID 486

#define LINK8_ID 518

#define LINK9_ID 550

#define LINK10_ID 582

#define LINK11_ID 614

#define LINK12_ID 646

#define LINK13_ID 678

#define LINK14_ID 710

#define LINK15_ID 742

extern const unsigned short GameOver_palette[256];
#define GAMEOVER_PALETTE_SIZE 256

extern const unsigned short GameOver[19200];
#define GAMEOVER_SIZE 19200
#define GAMEOVER_WIDTH 240
#define GAMEOVER_HEIGHT 160

#endif

