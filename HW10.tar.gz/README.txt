LEGEND OF ZELDA MINI GAME by Laura Cox
Objective: Get the key and open the door before stalfos gets you
Avoid: Stalfos (skeleton dude)

Note:
When you and Stalfos collide, he will be temporarily repelled. Be careful though because he has more lives than you.

KEYS:

START | ENTER
SELECT | BACKSPACE
LEFT | LEFT ARROW
RIGHT | RIGHT ARROW
UP | UP ARROW
DOWN | DOWN ARROW

Good luck!