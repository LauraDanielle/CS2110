/*
 * Exported with nin10kit v1.1
 * Time-stamp: Monday 11/09/2015, 13:28:12
 * 
 * Image Information
 * -----------------
 * /home/laura/Documents/HW10/TitleScreen.png 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef TITLESCREEN_H
#define TITLESCREEN_H

extern const unsigned short TitleScreen_palette[256];
#define TITLESCREEN_PALETTE_SIZE 256

extern const unsigned short TitleScreen[19200];
#define TITLESCREEN_SIZE 19200
#define TITLESCREEN_WIDTH 240
#define TITLESCREEN_HEIGHT 160

#endif

