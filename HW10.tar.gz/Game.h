/*
 * Exported with nin10kit v1.1
 * Time-stamp: Tuesday 11/10/2015, 01:36:00
 * 
 * Image Information
 * -----------------
 * /home/laura/Documents/HW10/door.jpg 30@30
 * /home/laura/Documents/HW10/key.png 20@20
 * /home/laura/Documents/HW10/link.gif (frame 0) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 1) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 2) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 3) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 4) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 5) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 6) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 7) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 8) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 9) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 10) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 11) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 12) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 13) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 14) 50@30
 * /home/laura/Documents/HW10/link.gif (frame 15) 50@30
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 0) 20@40
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 1) 20@40
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 2) 20@40
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 3) 20@40
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 4) 20@40
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 5) 20@40
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 6) 20@40
 * /home/laura/Documents/HW10/stalfos_enemy.gif (frame 7) 20@40
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef GAME_H
#define GAME_H

extern const unsigned short Game_palette[256];
#define GAME_PALETTE_SIZE 256

extern const unsigned short door[450];
#define DOOR_SIZE 450
#define DOOR_WIDTH 30
#define DOOR_HEIGHT 30

extern const unsigned short key[200];
#define KEY_SIZE 200
#define KEY_WIDTH 20
#define KEY_HEIGHT 20

extern const unsigned short link0[750];

extern const unsigned short link1[750];

extern const unsigned short link2[750];

extern const unsigned short link3[750];

extern const unsigned short link4[750];

extern const unsigned short link5[750];

extern const unsigned short link6[750];

extern const unsigned short link7[750];

extern const unsigned short link8[750];

extern const unsigned short link9[750];

extern const unsigned short link10[750];

extern const unsigned short link11[750];

extern const unsigned short link12[750];

extern const unsigned short link13[750];

extern const unsigned short link14[750];

extern const unsigned short link15[750];

extern const unsigned short stalfos_enemy0[400];

extern const unsigned short stalfos_enemy1[400];

extern const unsigned short stalfos_enemy2[400];

extern const unsigned short stalfos_enemy3[400];

extern const unsigned short stalfos_enemy4[400];

extern const unsigned short stalfos_enemy5[400];

extern const unsigned short stalfos_enemy6[400];

extern const unsigned short stalfos_enemy7[400];

extern const unsigned short* link_frames[16];
#define LINK_FRAMES 16
#define LINK_SIZE 750
#define LINK_WIDTH 50
#define LINK_HEIGHT 30

extern const unsigned short* stalfos_enemy_frames[8];
#define STALFOS_ENEMY_FRAMES 8
#define STALFOS_ENEMY_SIZE 400
#define STALFOS_ENEMY_WIDTH 20
#define STALFOS_ENEMY_HEIGHT 40

#endif

