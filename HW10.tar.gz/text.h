extern const unsigned char fontdata_6x8[12288];

void drawChar(int row, int col, char ch, u16 color);
void drawString(int row, int col, char *str, unsigned char index);