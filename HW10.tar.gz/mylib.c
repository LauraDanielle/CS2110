#include <stdio.h>
#include <stdlib.h>
#include "mylib.h"
#include "text.h"
#include "Game.h"

u16 *videoBuffer = (u16*)0x6000000;
#define SCANLINECOUNTER *(volatile u16 *)0x4000006

void setPixel4(int row, int col, u8 index) {
	int whichPixel = OFFSET(row, col, 240);
	int whichShort = whichPixel/2;
	if (col & 1) {
		// odd column
		videoBuffer[whichShort] = (videoBuffer[whichShort] & 0x00FF) | (index << 8);
	} else {
		videoBuffer[whichShort] = (videoBuffer[whichShort] & 0xFF00) | (index);
	}
}

/* drawRect4
* A Mode 4 implementation of drawRect. Must have even width. Takes in an index from the palette
*/
void drawRect(int row, int col, int h, int w, unsigned char index)
{
	volatile unsigned short color = index | (index << 8);
	int r;
	for(r=0; r<h; r++)
	{
		DMA[3].src = &color;
		DMA[3].dst = videoBuffer + OFFSET(row + r, col, 240)/2;
		DMA[3].cnt = w | DMA_ON | DMA_SOURCE_FIXED;
	}
}
/* drawImage4
* A function that will draw an arbitrary sized image
* onto the screen (with DMA).
* @param r row to draw the image
* @param c column to draw the image
* @param width width of the image
* @param height height of the image
* @param image pointer to the first element of the image
*/
void drawImage4(int r, int c, int width, int height, const u16* image) {
	for (int y = 0; y < height; y++) {
		DMA[3].src = &image[OFFSET(y, 0, width / 2)];
		DMA[3].dst = videoBuffer + OFFSET(r + y, c, 240)/2;
		DMA[3].cnt = (width/2) | DMA_ON;
	}
}

/* Flip the page that is currently being drawn on. Check to see
   which buffer is currently active and then switch it. */
void FlipPage()
{
	if(REG_DISPCTL & BUFFER1FLAG)
	{
		// We were displaying Buffer 1
		REG_DISPCTL = REG_DISPCTL & ~BUFFER1FLAG;
		videoBuffer = BUFFER1;
	}
	else
	{
		// We were displaying Buffer 0
		REG_DISPCTL = REG_DISPCTL | BUFFER1FLAG;
		videoBuffer = BUFFER0;
	}
}
//assigns the current palette to memory location
void fill_palette(const short unsigned int *palette) 
{
  for (int i=0; i<255; i++) {
    PALETTE[i] = palette[i];
  }
}

void waitForVblank()
{
    while(SCANLINECOUNTER > 160);
    while(SCANLINECOUNTER < 160);
}

//takes in palette index and fills the screen with that color
void fillScreen4(unsigned char index)
{
	volatile unsigned short color = index | (index << 8);
	DMA[3].src = &color;
	DMA[3].dst = videoBuffer;
	DMA[3].cnt = 19200 | DMA_SOURCE_FIXED | DMA_ON;
}

//function that checks if two objects have one pixel in common (includes the new position of each object)
int isCollided(int xPlace, int yPlace, int x, int y, int width1, int height1, int width2, int height2) {
	if (xPlace < x + width2 && xPlace + width1 > x && yPlace < y + height2 && height1 + yPlace > y) {
	    // collision detected!
	    return 1;
	}
 	return 0;
}



