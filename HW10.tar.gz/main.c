#include <stdio.h>
#include <stdlib.h>
#include "mylib.h"
#include "text.h"
#include "TitleScreen.h"
#include "GameOver.h"
#include "Game.h"

/*
@author Laura Cox
CS 2110
*/

//checks whether you have the key in your inventory
int have = 0;

//increments every time vblank is called; used for animation
int timer = 0;
//string to store lives of player and enemy
char string[100]; 
//image to store different frames of stalfos
const u16* image;

enum GBAState {
	START,
	GAME,
	WIN,
	LOSE

};
//function prototypes used in main
void game(player* link, player* stalfos);
int hasKey(player* link);
void stalfosMove(player* stalfos);
void win();
void lose();

int main(void) 
{
	REG_DISPCTL = MODE4 | BG2_ENABLE | BUFFER1FLAG;
	enum GBAState state = START;
	
	player link;
	player stalfos; //enemy and player struct


	while(1)
	{
		switch(state) {
		case START:
			fill_palette(TitleScreen_palette);
			drawImage4(0,0,240,160,TitleScreen);
			//set position of link to starting place (can reset game if select button pressed)
			link.xPlace = 10;
			link.yPlace = 10;
			link.dy = 1;
			link.dx = 1;
			link.lives = 3;

			//set position of stalfos to starting place (can reset game if select button pressed)
			stalfos.xPlace = 25;
			stalfos.yPlace = 200;
			stalfos.dy = 1;
			stalfos.dx = 1;
			stalfos.lives = 5;

			//player does not have key anymore if at home screen
			have = 0;
			if (KEY_DOWN_NOW(BUTTON_START)) {
				state = GAME;
			}
			break;
		case GAME:
			if (KEY_DOWN_NOW(BUTTON_SELECT)) {
				state = START;
			}
			fill_palette(sprites_palette); //fills with game palette
			fillScreen4(1); //makes backgroun black

			drawImage4(120, 200, DOOR_WIDTH, DOOR_HEIGHT, door); //draws door

			if (!hasKey(&link)) {
				drawImage4(10, 220, KEY_WIDTH, KEY_HEIGHT, key);
			}
			game(&link, &stalfos); //link movement function
			drawImage4(link.xPlace, link.yPlace, LINK_WIDTH, LINK_HEIGHT, link0);
			if (stalfos.lives > 0) {
				stalfosMove(&stalfos); //stalfos movement function; stops drawing him if he has zero lives
			}

				//checks if link is at door and has key
			if (isCollided(link.yPlace, link.xPlace, 200, 120, LINK_WIDTH, LINK_HEIGHT, DOOR_WIDTH, DOOR_HEIGHT) && (hasKey(&link))) {
				state = WIN;
			} else if (link.lives == 0) { //if link has no more lives he dies
				state = LOSE;
			}
			break;
		case WIN:
			if (KEY_DOWN_NOW(BUTTON_SELECT)) {
				state = START;
			}
			fill_palette(GameOver_palette); //fill with game over screen palette
			win();
			break;
		case LOSE:
			if (KEY_DOWN_NOW(BUTTON_SELECT)) {
				state = START;
			}
			fill_palette(GameOver_palette);
			lose();
			break;
		}
		
		waitForVblank();
		FlipPage();
		timer++;


	}
}
/*
Takes in player and enemy struct. Updates link's position and checks if stalfos and link collide
*/
void game(player* link, player* stalfos) {
	
	if (KEY_DOWN_NOW(BUTTON_RIGHT)) {
		link->yPlace += link->dy;

		if (link->yPlace < 235) { //upper y boundary
			drawImage4(link->xPlace, link->yPlace, LINK_WIDTH, LINK_HEIGHT, link0);
		}
	} else if (KEY_DOWN_NOW(BUTTON_LEFT)) {
		link->yPlace -= link->dy;
		if (link->yPlace > 5) { //lower y boundary
			drawImage4(link->xPlace, link->yPlace, LINK_WIDTH, LINK_HEIGHT, link0);
		}
	} else if (KEY_DOWN_NOW(BUTTON_DOWN)) {
		link->xPlace += link->dx;
		if (link->xPlace < 155 ) { //upper x boundary
			drawImage4(link->xPlace, link->yPlace, LINK_WIDTH, LINK_HEIGHT, link0);
		}
	} else if (KEY_DOWN_NOW(BUTTON_UP)) {
		link->xPlace -= link->dx;
		if (link->xPlace > 5) { //lower x boundary
			drawImage4(link->xPlace, link->yPlace, LINK_WIDTH, LINK_HEIGHT, link0);
		}
	}
	if (isCollided(link->yPlace, link->xPlace, stalfos->yPlace, stalfos->xPlace, LINK_WIDTH, LINK_HEIGHT, STALFOS_ENEMY_WIDTH, STALFOS_ENEMY_HEIGHT)) {
		link->lives -= 1; //decrements both lives after collision
		stalfos->lives -= 1;
		stalfos-> dx = stalfos->dx*(-1); //reverses stalfos's direction so another collision won't occur too quickly
		stalfos -> dy = stalfos->dy*(-1);


	}
		drawString(135, 5, "LINK", 0); //writes updated life count on the screen
		sprintf(string, "Lives : %d", link->lives);
		drawString(145, 5, string, 0);

		drawString(135, 130, "STALFOS", 0);
		sprintf(string, "Lives : %d", stalfos->lives);
		drawString(145, 130, string, 0);
	
}
//checks if player has collided with key
int hasKey(player* link) {

	if (isCollided(link->yPlace, link->xPlace, 220, 10, LINK_WIDTH, LINK_HEIGHT, KEY_WIDTH, KEY_HEIGHT)) {
		drawRect(10, 220, KEY_WIDTH, KEY_HEIGHT, 1); //delete key from screen
		drawString(100, 100, "You got the key!", 0); //print out message notifying player they have the key
		have = 1;
	}
	return have;
}
//interates through gif image of stalfos
void stalfosMove(player* stalfos) {
		//changes image of stalfos at 10 frams per second; mod timer by 8 (num frames) * 10 (rate of change)
		image = stalfos_enemy_frames[(timer % 80)/10];

		if (stalfos->xPlace == 125) { //upper x boundary for stalfos
			stalfos->dx = -1;

		} else if (stalfos->xPlace == 5) { //lower x boundary for stalfos
			stalfos->dx = 1;
		}

		if (stalfos->yPlace == 220) { //upper y boundary for stalfos
			stalfos->dy = -1;
		} else if (stalfos->yPlace == 5) { //lower y boundary for stalfos
			stalfos->dy = 1;
		}

			stalfos->xPlace += stalfos->dx;

			stalfos->yPlace += stalfos->dy;

		drawImage4(stalfos->xPlace, stalfos->yPlace, STALFOS_ENEMY_WIDTH, STALFOS_ENEMY_HEIGHT, image);
	
}

void win() { //draws game over screen and winner message
	drawImage4(0, 0, 240, 160, GameOver);
	drawString(100, 100, "You Win!", 0);
	drawString(120, 45, "Press Select to start again.", 0);
}

void lose() { //draws game over screen and loser message
	drawImage4(0, 0, 240, 160, GameOver);
	drawString(100, 100, "You Lose!", 0);
	drawString(120, 45, "Press Select to start again.", 0);
}