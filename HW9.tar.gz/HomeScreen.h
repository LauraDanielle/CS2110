#ifndef HOMESCREEN_BITMAP_H
#define HOMESCREEN_BITMAP_H
extern const unsigned short HomeScreen[40000];
#define HOMESCREEN_WIDTH 250
#define HOMESCREEN_HEIGHT 160
#endif