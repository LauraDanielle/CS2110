#ifndef YOUWIN_BITMAP_H
#define YOUWIN_BITMAP_H
extern const unsigned short YouWin[40000];
#define YOUWIN_WIDTH 250
#define YOUWIN_HEIGHT 160
#endif