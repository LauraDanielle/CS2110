#ifndef ASTEROID_BITMAP_H
#define ASTEROID_BITMAP_H
extern const unsigned short Asteroid[25];
#define ASTEROID_WIDTH 5
#define ASTEROID_HEIGHT 5
#endif