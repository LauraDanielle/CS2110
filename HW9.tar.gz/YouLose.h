#ifndef YOULOSE_BITMAP_H
#define YOULOSE_BITMAP_H
extern const unsigned short YouLose[40000];
#define YOULOSE_WIDTH 250
#define YOULOSE_HEIGHT 160
#endif