typedef unsigned short u16;


extern u16 *videoBuffer;


void setPixel(int r, int c, u16 color);
void drawRect(int r, int c, int width, int height, u16 color);
void drawHollowRect(int r, int c, int width, int height, u16 color);
void drawImage3(int r, int c, int width, int height, const u16* image);
void waitForVblank();
void eraseImage(int x, int y, int width, int xI, int yI, int widthI, int heightI,const unsigned short *image); 
int isCollided(int xPlace, int yPlace, int x, int y, int width1, int height1, int width2, int height2); 


typedef struct{
	int xPlace, yPlace, dy, dx;
	const u16 *pic;
}Nyan;

typedef struct{
	int x, y, dx;
	const u16 *object;
}Rock;
