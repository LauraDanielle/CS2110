#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mylib.h"
#include "HomeScreen.h" //all files for images used
#include "NyanCat.h"
#include "Asteroid.h"
#include "background.h"
#include "YouLose.h"
#include "YouWin.h"
#include "EndPiece.h"

#define REG_DISPCTL *(u16 *)0x4000000
#define MODE3 3
#define RGB(r,g,b) ((r) | (g)<<5 | (b)<<10) //macro to allow to get GBA colors
#define BLACK   RGB(0 , 0 , 0 )
#define WHITE   RGB(31, 31, 31)
#define RED     RGB(31, 0 , 0 )
#define GREEN   RGB(0 , 31, 0 )
#define BLUE    RGB(0 , 0 , 31)
#define YELLOW  RGB(31, 31, 0 )
#define MAGENTA RGB(31, 0 , 31)
#define CYAN    RGB(0 , 31, 31)
#define ORANGE  RGB(31, 15, 0 )
#define BROWN   RGB(18, 9 , 0 )
#define PURPLE  RGB(15, 0 , 15)
#define TEAL    RGB(0 , 15, 15)
#define MAROON  RGB(15, 0 , 0 )
#define GREY    RGB(15, 15, 15)
#define PINK    RGB(31, 18, 19)

#define BG2_ENABLE (1<<10)


#define BUTTON_A        (1<<0)
#define BUTTON_B        (1<<1)
#define BUTTON_SELECT   (1<<2)
#define BUTTON_START    (1<<3)
#define BUTTON_RIGHT    (1<<4)
#define BUTTON_LEFT     (1<<5)
#define BUTTON_UP       (1<<6)
#define BUTTON_DOWN     (1<<7)
#define BUTTON_R        (1<<8)
#define BUTTON_L        (1<<9)

#define KEY_DOWN_NOW(key) (~(BUTTONS) & key)

#define BUTTONS *(volatile unsigned int *)0x4000130


enum GBAState {
	START,
	START_NODRAW,
	GAME,
	GAME_NODRAW,
	WIN,
	LOSE,

};



int startPressed = 0;
int drawn = 0;
//keeps track of previous place of nyan cat
int tempPlaceX = 0;
int tempPlaceY = 0;

int astX = 0;
int astY = 0;
int main(void) {
	REG_DISPCTL = MODE3 | BG2_ENABLE;
	enum GBAState state = START;

	Nyan cat;
	cat.xPlace = 10;
	cat.yPlace = 10;
	cat.dy = 1;
	cat.dx = 1;
	cat.pic = NyanCat;

	Rock ast;
	ast.x = 5;
	ast.y = 120;
	ast.dx = 1;
	ast.object = Asteroid;
	while(1) {
		waitForVblank();
		if (!KEY_DOWN_NOW(BUTTON_START))
        {
			
			startPressed = 0;

         }
         		switch(state) {
         		case START:

         			drawImage3(0, 0, HOMESCREEN_WIDTH, HOMESCREEN_HEIGHT, HomeScreen);
         			state = START_NODRAW;
         			startPressed = 1;
         			drawn = 1;
         			break;
         		case START_NODRAW:
         			if (KEY_DOWN_NOW(BUTTON_START) && startPressed == 0) {
         				if (drawn == 0) {
         					startPressed = 1;
         					drawn = 1;
         					state = GAME;
         				}
         			}
         			break;
         		case GAME:
         			if (KEY_DOWN_NOW(BUTTON_SELECT)) {
         				state = START;
         				break;
         			}
         			//sets up inital background & nyan cat position
         			drawImage3(0, 0, BACKGROUND_WIDTH, BACKGROUND_HEIGHT, background);
         			drawImage3(80, 220, ENDPIECE_WIDTH, ENDPIECE_HEIGHT, EndPiece);
         			drawImage3(cat.xPlace, cat.yPlace, NYANCAT_WIDTH, NYANCAT_HEIGHT, cat.pic);
         			drawImage3(ast.x, ast.y, ASTEROID_WIDTH, ASTEROID_HEIGHT, ast.object);
         			startPressed = 1;
         			state = GAME_NODRAW;   			
         			break;
         		case GAME_NODRAW: //will continue looping through this state UNTIL goal or loss
         			//movement of Nyan cat

         			//asteroid change in position
         			astX = ast.x;
         			astY = ast.y;
         			if (ast.x > 155) {
         				ast.x = ast.x * -1;
         			} else {
         				ast.x =+ ast.dx;
         			}

         			eraseImage(0, 0, 240, astY, astX, ASTEROID_HEIGHT, ASTEROID_WIDTH,background); 
         			drawImage3(ast.x, ast.y, ASTEROID_WIDTH, ASTEROID_HEIGHT, ast.object);
         			
         			if (KEY_DOWN_NOW(BUTTON_SELECT)) {
         				state = START;
         				break;
         			}

         			tempPlaceX = cat.xPlace;
         			tempPlaceY = cat.yPlace;
         			if (KEY_DOWN_NOW(BUTTON_RIGHT)) {
         				
         				cat.yPlace += cat.dy; 
         				//boundary for the columns
         				if (cat.yPlace > 235) {
         					state = GAME_NODRAW;
         					break;
         				}
         				
         				eraseImage(0, 0, 240, tempPlaceY, tempPlaceX, NYANCAT_HEIGHT, NYANCAT_WIDTH,background); 
         				drawImage3(cat.xPlace, cat.yPlace, NYANCAT_WIDTH, NYANCAT_HEIGHT, cat.pic);
         				state = GAME_NODRAW;
         				
         			} else if (KEY_DOWN_NOW(BUTTON_LEFT)) {

         				cat.yPlace -= cat.dy; 
         				//boundary for columns (beginning of screen)
         				if (cat.yPlace < 5) {
         					state = GAME_NODRAW;
         					break;
         				}
         				eraseImage(0, 0, 240, tempPlaceY, tempPlaceX, NYANCAT_HEIGHT, NYANCAT_WIDTH,background); 
         				drawImage3(cat.xPlace, cat.yPlace, NYANCAT_WIDTH, NYANCAT_HEIGHT, cat.pic);
         				state = GAME_NODRAW;
         			} else if (KEY_DOWN_NOW(BUTTON_DOWN)) {

         				cat.xPlace += cat.dx;
         				//boundary for rows
  						if (cat.xPlace > 155) {
         					state = GAME_NODRAW;
         					break;
         				}
         				eraseImage(0, 0, 240, tempPlaceY, tempPlaceX, NYANCAT_HEIGHT, NYANCAT_WIDTH,background);
         				drawImage3(cat.xPlace, cat.yPlace, NYANCAT_WIDTH, NYANCAT_HEIGHT, cat.pic);
         				state = GAME_NODRAW;
         			} else if (KEY_DOWN_NOW(BUTTON_UP)) {
         				
         				cat.xPlace -= cat.dx;
         				//boundary of rows beginning of screen
         				if (cat.xPlace < 5) {
         					state = GAME_NODRAW;
         					break;
         				}
         				eraseImage(0, 0, 240, tempPlaceY, tempPlaceX, NYANCAT_HEIGHT, NYANCAT_WIDTH,background);
         				drawImage3(cat.xPlace, cat.yPlace, NYANCAT_WIDTH, NYANCAT_HEIGHT, cat.pic);
         				state = GAME_NODRAW;
         			}
         			if (isCollided(tempPlaceX, tempPlaceY, 80, 220, NYANCAT_WIDTH, NYANCAT_HEIGHT, ENDPIECE_WIDTH, ENDPIECE_HEIGHT)) {
         				state = WIN;
         			} else if (isCollided(tempPlaceX, tempPlaceY, astX, astY, NYANCAT_WIDTH, NYANCAT_HEIGHT, ASTEROID_WIDTH, ASTEROID_HEIGHT)) {
         				state = LOSE;
         			}

         			break;	
         		case WIN:
         			if (KEY_DOWN_NOW(BUTTON_SELECT)) {
         				state = START;
         				break;
         			}
         			drawImage3(0, 0, YOUWIN_WIDTH, YOUWIN_HEIGHT, YouWin);
         			break;
         		case LOSE:
         			if (KEY_DOWN_NOW(BUTTON_SELECT)) {
         				state = START;
         				break;
         			}
         			drawImage3(0, 0, YOULOSE_WIDTH, YOULOSE_HEIGHT, YouLose);
         			break;

         		}
		drawn = 0;
	}
	return(0);
}
