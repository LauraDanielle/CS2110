#ifndef NYANCAT_BITMAP_H
#define NYANCAT_BITMAP_H
extern const unsigned short NyanCat[900];
#define NYANCAT_WIDTH 30
#define NYANCAT_HEIGHT 30
#endif