#include <stdio.h>
#include <string.h>
#include "mylib.h"


u16 *videoBuffer = (u16*)0x6000000;
#define SCANLINECOUNTER *(volatile u16 *)0x4000006
// A function to set pixel (r, c) to the color passed in.
void setPixel(int r, int c, u16 color)
{
	videoBuffer[r*240+c] = color;
}
// A function to draw a FILLED rectangle starting at (r, c)
void drawRect(int r, int c, int width, int height, u16 color)
{
	for (int row = 0; row < height; row++) {
        	for (int col = 0; col < width; col++) {
            		setPixel(r+row, c+col, color);
        	}
    	}
}
// A function to draw a HOLLOW rectangle starting at (r,c)
// NOTE: It has to run in O(w+h) time.
void drawHollowRect(int r, int c, int width, int height, u16 color)
{
	for (int i = r; i <= (height+r); i++) {
		setPixel(i, c, color);
		setPixel(i, (width+c), color);
	}
	for (int j = c; j <= (width+c); j++) {
		setPixel(r, j, color);
		setPixel((height+r), j, color);
	}
}
/* drawimage3
* A function that will draw an arbitrary sized image
* onto the screen
* @param r row to draw the image
* @param c column to draw the image
* @param width width of the image
* @param height height of the image
* @param image Pointer to the first element of the image.
*/
void drawImage3(int r, int c, int width, int height, const u16 *image)
{
	for (int i = r; i <= (height+r); i++) {
		for (int j = c; j <= (width+c); j++) {
			videoBuffer[i*240+j] = image[(i-r)*width+(j-c)];
		}
	}

}
//takes in the changes of X/Y of nyan cat and "removes" old nyan cat by replacing it with the background
void eraseImage(int x, int y, int width, int xI, int yI, int widthI, int heightI, const unsigned short *image) 
{ 
//Iterate through each row 
	for (int b = yI; b < yI + heightI; b++) { 
	//Iterate through each column 
		for (int a = xI; a < xI + widthI; a++) { 
			videoBuffer[((b + y) * 240) + a + x] = image[b * width + a]; 
		} 
	} 
}
//prevents image from flickering
void waitForVblank()
{
    while(SCANLINECOUNTER > 160);
    while(SCANLINECOUNTER < 160);
}

int isCollided(int xPlace, int yPlace, int x, int y, int width1, int height1, int width2, int height2) {
	if (xPlace < x + width2 && xPlace + width1 > x && yPlace < y + height2 &&
	   height1 + yPlace > y) {
	    // collision detected!
	    return 1;
	}
 	return 0;
}