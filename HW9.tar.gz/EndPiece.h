#ifndef ENDPIECE_BITMAP_H
#define ENDPIECE_BITMAP_H
extern const unsigned short EndPiece[400];
#define ENDPIECE_WIDTH 20
#define ENDPIECE_HEIGHT 20
#endif